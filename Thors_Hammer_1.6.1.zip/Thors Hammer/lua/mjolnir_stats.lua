local _init_melee_weapons_actual = BlackMarketTweakData._init_melee_weapons
function BlackMarketTweakData:_init_melee_weapons(...)
    _init_melee_weapons_actual(self, ...)

-- Tenderizer --
self.melee_weapons.mjolnir.expire_t = 0.5
self.melee_weapons.mjolnir.repeat_expire_t = 1.0
self.melee_weapons.mjolnir.stats.weapon_type = "blunt"

end